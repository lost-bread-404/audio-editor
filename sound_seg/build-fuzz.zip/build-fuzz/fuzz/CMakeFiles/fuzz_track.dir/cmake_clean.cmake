file(REMOVE_RECURSE
  "CMakeFiles/fuzz_track.dir/fuzz_track.c.o"
  "CMakeFiles/fuzz_track.dir/fuzz_track.c.o.d"
  "fuzz_track"
  "fuzz_track.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/fuzz_track.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
