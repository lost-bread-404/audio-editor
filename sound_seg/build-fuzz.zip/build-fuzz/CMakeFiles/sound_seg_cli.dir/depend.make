# Empty dependencies file for sound_seg_cli.
# This may be replaced when dependencies are built.
