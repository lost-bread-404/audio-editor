#----------------------------------------------------------------
# Generated CMake target import file for configuration "Debug".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "sound_seg::sound_seg" for configuration "Debug"
set_property(TARGET sound_seg::sound_seg APPEND PROPERTY IMPORTED_CONFIGURATIONS DEBUG)
set_target_properties(sound_seg::sound_seg PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_DEBUG "C"
  IMPORTED_LOCATION_DEBUG "${_IMPORT_PREFIX}/lib/libsound_seg.a"
  )

list(APPEND _cmake_import_check_targets sound_seg::sound_seg )
list(APPEND _cmake_import_check_files_for_sound_seg::sound_seg "${_IMPORT_PREFIX}/lib/libsound_seg.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
