# Empty dependencies file for sound_seg.
# This may be replaced when dependencies are built.
