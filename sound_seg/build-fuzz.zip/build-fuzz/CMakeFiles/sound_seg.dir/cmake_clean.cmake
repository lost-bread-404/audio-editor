file(REMOVE_RECURSE
  "CMakeFiles/sound_seg.dir/src/sound_seg.c.o"
  "CMakeFiles/sound_seg.dir/src/sound_seg.c.o.d"
  "CMakeFiles/sound_seg.dir/src/sound_seg_extra.c.o"
  "CMakeFiles/sound_seg.dir/src/sound_seg_extra.c.o.d"
  "libsound_seg.a"
  "libsound_seg.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/sound_seg.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
