file(REMOVE_RECURSE
  "libsound_seg.a"
)
