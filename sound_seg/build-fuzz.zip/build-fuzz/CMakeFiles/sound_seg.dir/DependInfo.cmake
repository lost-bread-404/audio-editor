
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/src/sound_seg.c" "CMakeFiles/sound_seg.dir/src/sound_seg.c.o" "gcc" "CMakeFiles/sound_seg.dir/src/sound_seg.c.o.d"
  "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/src/sound_seg_extra.c" "CMakeFiles/sound_seg.dir/src/sound_seg_extra.c.o" "gcc" "CMakeFiles/sound_seg.dir/src/sound_seg_extra.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
