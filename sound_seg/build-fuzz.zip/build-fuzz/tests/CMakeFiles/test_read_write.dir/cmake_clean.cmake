file(REMOVE_RECURSE
  "CMakeFiles/test_read_write.dir/test_read_write.c.o"
  "CMakeFiles/test_read_write.dir/test_read_write.c.o.d"
  "test_read_write"
  "test_read_write.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_read_write.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
