file(REMOVE_RECURSE
  "CMakeFiles/test_delete.dir/test_delete.c.o"
  "CMakeFiles/test_delete.dir/test_delete.c.o.d"
  "test_delete"
  "test_delete.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_delete.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
