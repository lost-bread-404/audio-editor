# CMake generated Testfile for 
# Source directory: /Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests
# Build directory: /Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/build-fuzz/tests
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(test_read_write "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/build-fuzz/tests/test_read_write")
set_tests_properties(test_read_write PROPERTIES  _BACKTRACE_TRIPLES "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;5;add_test;/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;8;add_ss_test;/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;0;")
add_test(test_delete "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/build-fuzz/tests/test_delete")
set_tests_properties(test_delete PROPERTIES  _BACKTRACE_TRIPLES "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;5;add_test;/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;9;add_ss_test;/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;0;")
add_test(test_errors "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/build-fuzz/tests/test_errors")
set_tests_properties(test_errors PROPERTIES  _BACKTRACE_TRIPLES "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;5;add_test;/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;10;add_ss_test;/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;0;")
add_test(test_context "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/build-fuzz/tests/test_context")
set_tests_properties(test_context PROPERTIES  _BACKTRACE_TRIPLES "/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;5;add_test;/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;11;add_ss_test;/Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/tests/CMakeLists.txt;0;")
