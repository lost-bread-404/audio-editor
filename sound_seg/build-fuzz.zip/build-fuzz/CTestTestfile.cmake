# CMake generated Testfile for 
# Source directory: /Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg
# Build directory: /Users/rosyyu/Downloads/mnt/user-data/outputs/sound_seg/build-fuzz
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("tests")
subdirs("fuzz")
